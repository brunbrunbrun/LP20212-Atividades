#ifndef MODULOS_H
#define MODULOS_H

typedef struct Funcionarios
{
  char nome[100];
  char cargo[100];
  float salario;
  int dependentes;
}Funcionarios;


void opcao_1();
void opcao_2();
void opcao_3();

#endif
